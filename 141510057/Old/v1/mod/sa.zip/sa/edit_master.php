<?php
if ($_GET['get']=='edit_master_barang') { ?>

<h3 class="page-header"><i class="fa fa-cog"></i> | <i class="fa fa-edit"></i> Ubah Master Barang</h3>
<div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">

                            <!--<div class="panel-heading">
                           <i class="icon fa fa-edit"> Edit Data</i>-->
                            <!--</div>-->


                            <!-- /.panel-heading -->
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-basic table-hover" id="dataTables-example" >
                                        <thead>
                                            <tr>
                                                <th >#</th>
                                                <th>Kode Barang</th>
                                                <th>Nama Barang</th>
                                                <th>Kode</th>
                                                <th>Lainnya</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 


        $query = mysqli_query($koneksi, "SELECT * FROM barang order by kd_barang")or die(mysql_error());
        $nomor = 1;
        while($data = mysqli_fetch_array($query)){
        ?>
        
        <tr>
            <td ><?php echo $nomor++; ?></td>
            <td><?php echo $data['kd_barang']; ?></td>
            <td><?php echo $data['nm_barang']; ?></td>
            <td><a href="?get=form_master_barang&form=edit_kd_barang&id=<?php echo $data['id'];?>"><i class="icon fa fa-check-square" title="Edit Kode Barang"></i></a></td>
            <td> <a href="?get=form_master_barang&form=edit_barang&id=<?php echo $data['id'];?>"><i class="icon fa fa-check-square-o" title="Edit Data lainnya"></i></a></td>
        </tr>
        
        <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.table-responsive -->



                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                </div>
                                </div>
                            <!--</div>-->
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
<?php
}
?>