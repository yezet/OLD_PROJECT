<?php
//include('./connect.php');
if ($_GET['form']=='add_barang') { ?> 


<h3 class="page-header"><i class="fa fa-cog"></i> | <i class="fa fa-plus-circle"></i> Tambah Data</h3>
<div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Form Master Barang
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-12">

                                        <form role="form" method="post" action="mod/sa/process.php?act=add_barang">
                                        <div class="col-lg-6">    
                                            <div class="form-group">
                                                <label>Kode Barang</label>
                                                <!--<input class="form-control" name="id" type="hidden" placeholder="id" autofocus required>-->
                                                <input class="form-control" name="kd_barang" type="text" placeholder="Kode Barang" autofocus required>
                                            </div>
                                            <div class="form-group">
                                                <label>Nama Barang</label>
                                                <input class="form-control" name="nm_barang" type="text" placeholder="Nama Barang" required autofocus>
                                            </div>
                                            <div class="form-group">
                                                <label>Satuan</label>
                                                <input class="form-control" name="satuan" type="text" placeholder="Satuan" required autofocus>
                                            </div>
                                            <div class="form-group">
                                                <label>Kategori</label>
                                                <input class="form-control" name="kategori" type="text" placeholder="Kategori" required autofocus>
                                            </div>
                                            <div class="form-group">
                                                <label>Keterangan</label>
                                                <input class="form-control" name="ket" type="text" placeholder="Ket" required autofocus>
                                            </div>
                                            <div class="form-group">
                                                
                                                <input type="submit" class="btn btn-outline btn-primary btn-block" value="Tambah">
                                            </div>
                                        </div>
                                        </form>
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<?php
}
elseif ($_GET['form']=='edit_kd_barang') { 
	if (isset($_GET['id'])) {
        $query = mysqli_query($koneksi, "SELECT kd_barang, nm_barang, satuan, kategori, ket FROM barang WHERE id = '$_GET[id]'") or die('Kesalahan query : '.mysqli_error($koneksi));
        $data = mysqli_fetch_assoc ($query); }
?>
	<h3 class="page-header"><i class="fa fa-cog"></i> | <i class="fa fa-plus-edit"></i> Edit Kode Barang</h3>
<div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Edit Kode Barang
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <form role="form" method="post" action="mod/sa/process.php?act=update_kd_barang">
                                            
                                            <div class="form-group">
                                                <label>Kode Barang</label>
                                                <input class="form-control" name="id" type="hidden" placeholder="id" autofocus required>
                                                <input class="form-control" name="kd_barang" type="text" value="<?php echo $data['kd_barang']; ?>">

                                            </div>
                                            <div class="form-group">
                                                <label>Nama Barang</label>
                                                <input class="form-control" name="nm_barang" type="text" value="<?php echo $data['nm_barang']; ?>"readonly>
                                            </div>
                                            <div class="form-group">
                                                <label>Satuan</label>
                                                <input class="form-control" name="satuan" type="text" value="<?php echo $data['satuan']; ?>"readonly>                                            </div>
                                            <div class="form-group">
                                                <label>Kategori</label>
                                                <input class="form-control" name="kategori" type="text" value="<?php echo $data['kategori']; ?>"readonly>
                                            </div>
                                            <div class="form-group">

                                                <input class="form-control" name="ket" type="hidden" value="<?php echo $data['ket']; ?>">
                                            </div>
                                            
                                            <div class="form-group">
                                                
                                                <input type="submit" class="btn btn-outline btn-primary btn-block" value="Update">
                                            </div>
                                            
                                        </form>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>


<?php 
}


elseif ($_GET['form']=='edit_barang') { 
	if (isset($_GET['id'])) {
        $query = mysqli_query($koneksi, "SELECT kd_barang, nm_barang, satuan, kategori, ket FROM barang WHERE id = '$_GET[id]'") or die('Kesalahan query : '.mysqli_error($koneksi));
        $data = mysqli_fetch_assoc ($query); }
?>
	<h3 class="page-header"><i class="fa fa-cog"></i> | <i class="fa fa-edit"></i> Edit Data</h3>
<div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <!--Form Master Barang-->
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <form role="form" method="post" action="mod/sa/process.php?act=update_barang">
                                            
                                            <div class="form-group">
                                                <label>Kode Barang</label>
                                                <input class="form-control" name="id" type="hidden" placeholder="id" autofocus required>
                                                <input class="form-control" name="kd_barang" type="text" value="<?php echo $data['kd_barang']; ?>" readonly ><a href="?get=edit_master_barang" onclick="return confirm ('Silahkan kembali ke halaman Ubah Master Barang kemudian pilih Kode Barang : <?php echo $data['kd_barang']; ?> untuk melakukan perubahan data.')"><i class="icon fa fa-edit"></i>Edit Kode Barang</a>

                                            </div>
                                            <div class="form-group">
                                                <label>Nama Barang</label>
                                                <input class="form-control" name="nm_barang" type="text" value="<?php echo $data['nm_barang']; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label>Satuan</label>
                                                <input class="form-control" name="satuan" type="text" value="<?php echo $data['satuan']; ?>">                                            </div>
                                            <div class="form-group">
                                                <label>Kategori</label>
                                                <input class="form-control" name="kategori" type="text" value="<?php echo $data['kategori']; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label>Keterangan</label>
                                                <input class="form-control" name="ket" type="text" value="<?php echo $data['ket']; ?>">
                                            </div>
                                            
                                            <div class="form-group">
                                                
                                                <input type="submit" class="btn btn-outline btn-primary btn-block" value="Update">
                                            </div>
                                            
                                        </form>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>


<?php 
}

?>
