<?php
//include('./connect.php');
if ($_GET['form']=='add_barang') { ?> 


<h3 class="page-header"><i class="fa fa-plus-circle"> Tambah Data</i></h3>
<div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Form Master Barang
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="col-lg-6">
                                        <form role="form" method="post" action="mod/barang/process.php?act=add_barang">
                                            <div class="form-group">
                                                <label>Kode Barang</label>
                                                <!--<input class="form-control" name="id" type="hidden" placeholder="id" autofocus required>-->
                                                <input class="form-control" name="kd_barang" type="text" placeholder="Kode Barang" autofocus required>
                                            </div>
                                            <div class="form-group">
                                                <label>Nama Barang</label>
                                                <input class="form-control" name="nm_barang" type="text" placeholder="Nama Barang" required autofocus>
                                            </div>
                                            <div class="form-group">
                                                <label>Satuan</label>
                                                <input class="form-control" name="satuan" type="text" placeholder="Satuan" required autofocus>
                                            </div>
                                            <div class="form-group">
                                                <label>Kategori</label>
                                                <input class="form-control" name="kategori" type="text" placeholder="Kategori" required autofocus>
                                            </div>
                                            <div class="form-group">
                                                <label>Keterangan</label>
                                                <input class="form-control" name="ket" type="text" placeholder="Ket" required autofocus>
                                            </div>
                                            <input type="submit" class="btn btn-outline btn-primary btn-block" value="Tambah">
                                        
                                        </form>
                                        </div>
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<?php
}
elseif ($_GET['form']=='edit_barang') { 
	if (isset($_GET['id'])) {
        $query = mysqli_query($koneksi, "SELECT kd_barang, nm_barang, satuan, kategori, ket FROM barang WHERE id = '$_GET[id]'") or die('Kesalahan query : '.mysqli_error($koneksi));
        $data = mysqli_fetch_assoc ($query); }
?>
	<h3 class="page-header">Edit Data</h3>
<div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Form Master Barang
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <form role="form" method="post" action="mod/barang/process.php?act=update_barang">
                                            
                                            <div class="form-group">
                                                <label>Kode Barang</label>
                                                <input class="form-control" name="id" type="hidden" placeholder="id" autofocus required>
                                                <input class="form-control" name="kd_barang" type="text" value="<?php echo $data['kd_barang']; ?>" readonly ><a href="index.php" onclick="return confirm ('Silahkan login sebagai System Administrator untuk dapat melakukan perubahan data Kode Barang : <?php echo $data['kd_barang']; ?>')"><i class="icon fa fa-edit" title="Hapus data"></i> Ubah Kode Barang</a>

                                            </div>
                                            <div class="form-group">
                                                <label>Nama Barang</label>
                                                <input class="form-control" name="nm_barang" type="text" value="<?php echo $data['nm_barang']; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label>Satuan</label>
                                                <input class="form-control" name="satuan" type="text" value="<?php echo $data['satuan']; ?>">                                            </div>
                                            <div class="form-group">
                                                <label>Kategori</label>
                                                <input class="form-control" name="kategori" type="text" value="<?php echo $data['kategori']; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label>Keterangan</label>
                                                <input class="form-control" name="ket" type="text" value="<?php echo $data['ket']; ?>">
                                            </div>
                                            
                                            <div class="form-group">
                                                
                                                <input type="submit" class="btn btn-outline btn-primary btn-block" value="Update">
                                            </div>
                                            
                                        </form>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>


<?php 
}



elseif ($_GET['form']=='editkd') { 
	if (isset($_GET['kd'])) {
        $query = mysqli_query($koneksi, "SELECT kd_barang, nm_barang, satuan, kategori, stok, ket FROM barang WHERE kd_barang = '$_GET[kd]'") or die('Kesalahan query : '.mysqli_error($koneksi));
        $data = mysqli_fetch_assoc ($query); }
?>
	<h1 class="page-header">Edit Data</h1>
<div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Form Barang
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <form role="form" method="post" action="modul/barang/proses.php?act=update">
                                            
                                            <div class="form-group">
                                                <label>Kode Barang</label>
                                                <!--<input class="form-control" name="id" type="hidden" placeholder="id" autofocus required>-->
                                                <input class="form-control" name="kd_barang" type="text" value="<?php echo $data['kd_barang']; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label>Nama Barang</label>
                                                <input class="form-control" name="nm_barang" type="text" value="<?php echo $data['nm_barang']; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label>Satuan</label>
                                                <input class="form-control" name="satuan" type="text" value="<?php echo $data['satuan']; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label>Kategori</label>
                                                <input class="form-control" name="kategori" type="text" value="<?php echo $data['kategori']; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label>Stok</label>
                                                <input class="form-control" name="stok" type="text" value="<?php echo $data['stok']; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label>Keterangan</label>
                                                <input class="form-control" name="ket" type="text" value="<?php echo $data['ket']; ?>">
                                            </div>
                                            
                                            <div class="form-group">
                                                
                                                <input type="submit" class="btn btn-outline btn-primary btn-block" value="Update">
                                            </div>
                                            
                                        </form>
                                    </div>

                                    <div class="col-lg-6">
                                        <form role="form">
                                            <div class="form-group">
                                                <p class="help-block">Opsi</p>
                                                <a class="icon fa fa-edit fa-1x" href="?mod=form_barang&form=edit&id=<?php echo $data['kd_barang'];?>"> Edit Kode Barang</a>
                                            </div>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>


<?php 
}

?>
