<?php
if(isset($_GET['add'])){
	include "mod/member/form.php";
}
?>