<?php 
// isi nama host, username mysql, dan password mysql anda
//$host = mysql_connect("localhost","root","toor");

// isikan dengan nama database yang akan di hubungkan
//$db = mysql_select_db("project");

/*


$dbhost = 'localhost'; 
$dbuser = 'root';
$dbpass = 'toor';
$dbname = 'edit';

$koneksi = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname) or die('koneksi gagal');

*/
$koneksi = mysqli_connect("localhost","yzzymyid_root","P@ssw0rd2019","yzzymyid_links") or die("koneksi gagal");

?>